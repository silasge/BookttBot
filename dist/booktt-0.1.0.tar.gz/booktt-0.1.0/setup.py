# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['booktt']

package_data = \
{'': ['*']}

install_requires = \
['tweepy>=3.10.0,<4.0.0']

entry_points = \
{'console_scripts': ['booktt = booktt.booktt:main']}

setup_kwargs = {
    'name': 'booktt',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Silas Genário',
    'author_email': 'silasge.lopes@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
